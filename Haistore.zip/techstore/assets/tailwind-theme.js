// Bảng màu "slate" được đổi sang tông đỏ sẫm để toàn bộ giao diện chuyển sang màu đỏ.
tailwind.config = { theme: { extend: { colors: { slate: {
  50:'#FEF2F2',100:'#FDE4E4',200:'#F5CACA',300:'#E3A8A8',400:'#BC8080',
  500:'#915A5A',600:'#6B3A3A',700:'#4A2323',800:'#2E1414',900:'#1A0909',950:'#110505'
}}}}};
