<?php require_once 'includes/helpers.php';
$st=$pdo->prepare("SELECT p.*,c.name cname FROM products p JOIN categories c ON c.id=p.category_id WHERE p.id=?"); $st->execute([(int)($_GET['id']??0)]); $p=$st->fetch();
if(!$p){ http_response_code(404); die('Không tìm thấy sản phẩm'); }
if($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['comment'])){
  $pdo->prepare("INSERT INTO reviews(product_id,author,rating,comment) VALUES(?,?,?,?)")->execute([$p['id'],trim($_POST['author'])?:'Khách',(int)$_POST['rating'],trim($_POST['comment'])]);
  header("Location: detail.php?id={$p['id']}#reviews"); exit; }
$title=$p['name']; require 'includes/header.php';
$now=$p['sale_price'] ?: $p['price']; $specs=json_decode($p['specs'],true) ?: [];
$rv=$pdo->prepare("SELECT * FROM reviews WHERE product_id=? ORDER BY id DESC"); $rv->execute([$p['id']]); $rv=$rv->fetchAll();
$rel=$pdo->prepare("SELECT * FROM products WHERE category_id=? AND id<>? LIMIT 4"); $rel->execute([$p['category_id'],$p['id']]); ?>
<div class="max-w-7xl mx-auto px-4 mt-8 grid md:grid-cols-2 gap-8">
 <div class="glass rounded-3xl h-96 flex items-center justify-center overflow-hidden group"><div class="transition duration-500 group-hover:scale-125 w-full h-full flex items-center justify-center"><?=thumb($p,'text-9xl')?></div></div>
 <div><p class="text-red-400 text-sm"><?=e($p['cname'])?> · <?=e($p['brand'])?></p>
  <h1 class="text-3xl font-black mt-1"><?=e($p['name'])?></h1>
  <p class="text-sm text-slate-400 mt-2">SKU: <?=e($p['sku'])?> · <?=$p['stock']>0?'<span class="text-emerald-400">Còn hàng ('.$p['stock'].')</span>':'<span class="text-red-400">Hết hàng</span>'?></p>
  <div class="mt-4"><span class="text-4xl font-black text-red-400 neon"><?=money($now)?></span>
   <?php if($p['sale_price']): ?><span class="line-through text-slate-500 ml-3"><?=money($p['price'])?></span><?php endif; ?></div>
  <p class="mt-3 text-slate-300"><?=e($p['short_desc'])?></p>
  <div class="flex flex-wrap gap-2 mt-4"><?php foreach(array_slice($specs,0,4) as $k=>$v): ?><span class="text-xs px-3 py-1 rounded-full bg-rose-500/20 border border-rose-500/40"><?=e($k)?>: <?=e($v)?></span><?php endforeach; ?></div>
  <div class="flex gap-3 mt-6 items-center"><input type="number" id="qty" value="1" min="1" max="<?=$p['stock']?>" class="w-20 text-center">
   <button onclick="addToCart(<?=$p['id']?>,+qty.value)" class="flex-1 py-3 rounded-xl border border-red-500 text-red-400 font-bold hover:bg-red-500 hover:text-slate-900 transition">Thêm vào giỏ</button>
   <button onclick="addToCart(<?=$p['id']?>,+qty.value);setTimeout(()=>location='cart.php',400)" class="flex-1 btn py-3 rounded-xl font-bold">Mua ngay</button></div></div></div>

<div class="max-w-7xl mx-auto px-4 mt-10 glass rounded-2xl p-6"><h2 class="font-bold text-xl mb-3">Thông số kỹ thuật</h2>
 <table class="w-full text-sm"><?php foreach($specs as $k=>$v): ?><tr class="border-b border-slate-700/50"><td class="py-2 text-slate-400 w-1/3"><?=e($k)?></td><td><?=e($v)?></td></tr><?php endforeach; ?></table>
 <h2 class="font-bold text-xl mt-6 mb-2">Mô tả</h2><p class="text-slate-300"><?=nl2br(e($p['description']))?></p></div>

<div id="reviews" class="max-w-7xl mx-auto px-4 mt-6 grid md:grid-cols-2 gap-6">
 <div class="glass rounded-2xl p-6"><h2 class="font-bold text-xl mb-3">Đánh giá (<?=count($rv)?>)</h2>
  <?php foreach($rv as $r): ?><div class="border-b border-slate-700/50 py-3"><b><?=e($r['author'])?></b> <span class="text-yellow-400"><?=str_repeat('★',$r['rating'])?></span><p class="text-slate-300 text-sm"><?=e($r['comment'])?></p></div><?php endforeach; ?></div>
 <form method="post" class="glass rounded-2xl p-6 space-y-3"><h2 class="font-bold text-xl">Viết đánh giá</h2>
  <input name="author" placeholder="Tên của bạn" class="w-full"><select name="rating" class="w-full"><?php for($i=5;$i>=1;$i--) echo "<option value=$i>$i sao</option>"; ?></select>
  <textarea name="comment" required rows="3" placeholder="Nội dung..." class="w-full"></textarea><button class="btn px-6 py-2 rounded-xl font-bold">Gửi</button></form></div>

<div class="max-w-7xl mx-auto px-4 mt-10"><h2 class="font-bold text-xl mb-4">Sản phẩm cùng phân khúc</h2>
 <div class="grid grid-cols-2 md:grid-cols-4 gap-4"><?php foreach($rel as $r) echo card($r); ?></div></div>
<?php require 'includes/footer.php'; ?>
