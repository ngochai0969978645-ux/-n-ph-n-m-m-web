<?php $title='Sản phẩm'; require 'includes/header.php';
$w=['1=1']; $a=[];
if(!empty($_GET['cat'])){ $w[]='c.slug=?'; $a[]=$_GET['cat']; }
if(!empty($_GET['q'])){ $w[]='p.name LIKE ?'; $a[]='%'.$_GET['q'].'%'; }
if(!empty($_GET['brand'])){ $in=implode(',',array_fill(0,count($_GET['brand']),'?')); $w[]="p.brand IN ($in)"; $a=array_merge($a,$_GET['brand']); }
$max=(int)($_GET['max'] ?? 100000000); $w[]='COALESCE(p.sale_price,p.price)<=?'; $a[]=$max;
$sorts=['new'=>'p.id DESC','asc'=>'COALESCE(p.sale_price,p.price) ASC','desc'=>'COALESCE(p.sale_price,p.price) DESC','hot'=>'p.sold DESC'];
$o=$sorts[$_GET['sort'] ?? 'new'] ?? $sorts['new'];
$where=implode(' AND ',$w); $per=8; $pg=max(1,(int)($_GET['page']??1));
$st=$pdo->prepare("SELECT COUNT(*) FROM products p JOIN categories c ON c.id=p.category_id WHERE $where"); $st->execute($a); $total=$st->fetchColumn();
$st=$pdo->prepare("SELECT p.* FROM products p JOIN categories c ON c.id=p.category_id WHERE $where ORDER BY $o LIMIT $per OFFSET ".(($pg-1)*$per)); $st->execute($a); $rows=$st->fetchAll();
$brands=$pdo->query("SELECT DISTINCT brand FROM products ORDER BY brand")->fetchAll(PDO::FETCH_COLUMN);
$qs=function($x){ return '?'.http_build_query(array_merge($_GET,$x)); }; ?>
<div class="max-w-7xl mx-auto px-4 mt-8 grid md:grid-cols-4 gap-6">
 <form class="glass rounded-2xl p-5 h-fit space-y-5">
  <?php foreach(['cat','q'] as $k) if(!empty($_GET[$k])) echo '<input type="hidden" name="'.$k.'" value="'.e($_GET[$k]).'">'; ?>
  <h3 class="font-bold text-red-400"><i class="fa-solid fa-sliders"></i> Bộ lọc</h3>
  <div><label class="text-sm text-slate-400">Giá tối đa: <b id="mv" class="text-red-400"><?=money($max)?></b></label>
   <input type="range" name="max" min="500000" max="100000000" step="500000" value="<?=$max?>" class="w-full accent-red-400 p-0" oninput="mv.textContent=Number(this.value).toLocaleString('vi-VN')+'₫'"></div>
  <div><p class="text-sm text-slate-400 mb-2">Thương hiệu</p><?php foreach($brands as $b): ?>
   <label class="flex items-center gap-2 text-sm py-0.5"><input type="checkbox" name="brand[]" value="<?=e($b)?>" <?=in_array($b,$_GET['brand']??[])?'checked':''?>><?=e($b)?></label><?php endforeach; ?></div>
  <button class="btn w-full py-2 rounded-xl font-bold">Áp dụng</button></form>
 <div class="md:col-span-3"><div class="flex justify-between items-center mb-4"><p class="text-slate-400"><?=$total?> sản phẩm</p>
  <select onchange="location='<?=$qs(['sort'=>'','page'=>1])?>'.replace('sort=','sort='+this.value)">
   <?php foreach(['new'=>'Mới nhất','hot'=>'Bán chạy','asc'=>'Giá tăng dần','desc'=>'Giá giảm dần'] as $k=>$v) echo '<option value="'.$k.'" '.(($_GET['sort']??'')==$k?'selected':'').'>'.$v.'</option>'; ?></select></div>
  <div class="grid grid-cols-2 lg:grid-cols-3 gap-4"><?php foreach($rows as $p) echo card($p); ?></div>
  <?php if(!$rows) echo '<p class="text-center text-slate-400 py-20">Không tìm thấy sản phẩm.</p>'; ?>
  <div class="flex justify-center gap-2 mt-8"><?php for($i=1;$i<=ceil($total/$per);$i++): ?>
   <a href="<?=$qs(['page'=>$i])?>" class="w-10 h-10 grid place-items-center rounded-xl <?=$i==$pg?'btn':'glass hover:glow'?>"><?=$i?></a><?php endfor; ?></div></div></div>
<?php require 'includes/footer.php'; ?>
