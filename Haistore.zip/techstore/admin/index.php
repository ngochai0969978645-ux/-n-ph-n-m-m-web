<?php require '../includes/helpers.php'; if(empty($_SESSION['admin'])){ header('Location: login.php'); exit; }
if(isset($_GET['logout'])){ unset($_SESSION['admin']); header('Location: login.php'); exit; }
if(isset($_POST['oid'])){ $pdo->prepare("UPDATE orders SET status=? WHERE id=?")->execute([$_POST['status'],(int)$_POST['oid']]); header('Location: index.php?tab=orders'); exit; }
if(isset($_POST['add'])){ $img=null;
 if(!empty($_FILES['image']['name']) && preg_match('/\.(jpe?g|png|webp)$/i',$_FILES['image']['name'])){ $img=uniqid().'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION); move_uploaded_file($_FILES['image']['tmp_name'],'../uploads/'.$img); }
 $pdo->prepare("INSERT INTO products(category_id,name,sku,brand,price,sale_price,stock,short_desc,description,specs,image) VALUES(?,?,?,?,?,?,?,?,?,?,?)")
  ->execute([$_POST['category_id'],$_POST['name'],$_POST['sku'],$_POST['brand'],$_POST['price'],$_POST['sale_price']?:null,$_POST['stock'],$_POST['short_desc'],$_POST['short_desc'],'{}',$img]); header('Location: index.php?tab=products'); exit; }
if(isset($_GET['del'])){ try{ $pdo->prepare("DELETE FROM products WHERE id=?")->execute([(int)$_GET['del']]); }catch(Exception $e){} header('Location: index.php?tab=products'); exit; }
$tab=$_GET['tab'] ?? 'dash';
$rev=$pdo->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE status<>'cancelled'")->fetchColumn();
$cnt=$pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn(); $pc=$pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$chart=$pdo->query("SELECT DATE(created_at) d,SUM(total) s FROM orders WHERE status<>'cancelled' GROUP BY d ORDER BY d DESC LIMIT 7")->fetchAll();
$orders=$pdo->query("SELECT * FROM orders ORDER BY id DESC")->fetchAll();
$prods=$pdo->query("SELECT p.*,c.name cn FROM products p JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC")->fetchAll();
$cats=$pdo->query("SELECT * FROM categories")->fetchAll();
$stl=['pending'=>'Chờ xử lý','shipping'=>'Đang giao','done'=>'Hoàn thành','cancelled'=>'Đã hủy']; ?>
<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin</title>
<script src="https://cdn.tailwindcss.com"></script><script src="<?=BASE?>assets/tailwind-theme.js"></script><link rel="stylesheet" href="<?=BASE?>assets/theme.css"><script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>input,select,textarea{background:#1A0909;border:1px solid #5A2D2D;border-radius:.75rem;padding:.5rem;color:#F8FAFC}</style></head>
<body class="bg-slate-900 text-slate-50 flex min-h-screen">
<aside id="sb" class="w-56 bg-slate-800 p-4 space-y-2 shrink-0 hidden md:block"><h1 class="text-xl font-black text-red-400 mb-4"><i class="fa-solid fa-bolt"></i> Hai Store Admin</h1>
 <?php foreach(['dash'=>['Dashboard','fa-chart-line'],'orders'=>['Đơn hàng','fa-receipt'],'products'=>['Sản phẩm','fa-box']] as $k=>$v): ?>
 <a href="?tab=<?=$k?>" class="block px-3 py-2 rounded-xl <?=$tab==$k?'bg-red-500 text-slate-900 font-bold':'hover:bg-slate-700'?>"><i class="fa-solid <?=$v[1]?> mr-2"></i><?=$v[0]?></a><?php endforeach; ?>
 <a href="../" class="block px-3 py-2 hover:bg-slate-700 rounded-xl"><i class="fa-solid fa-store mr-2"></i>Xem website</a>
 <a href="?logout=1" class="block px-3 py-2 text-red-400"><i class="fa-solid fa-right-from-bracket mr-2"></i>Đăng xuất</a></aside>
<main class="flex-1 p-6 overflow-x-auto"><button class="md:hidden mb-3" onclick="sb.classList.toggle('hidden')"><i class="fa-solid fa-bars"></i></button>
<?php if($tab=='dash'): ?><div class="grid md:grid-cols-3 gap-4">
 <?php foreach([['Doanh thu',number_format($rev,0,',','.').'₫'],['Đơn hàng',$cnt],['Sản phẩm',$pc]] as $s): ?><div class="bg-slate-800 rounded-2xl p-5"><p class="text-slate-400 text-sm"><?=$s[0]?></p><p class="text-3xl font-black text-red-400"><?=$s[1]?></p></div><?php endforeach; ?></div>
 <div class="bg-slate-800 rounded-2xl p-5 mt-4"><canvas id="ch" height="90"></canvas></div>
 <script>new Chart(ch,{type:'bar',data:{labels:<?=json_encode(array_reverse(array_column($chart,'d')))?>,datasets:[{label:'Doanh thu (₫)',data:<?=json_encode(array_map('intval',array_reverse(array_column($chart,'s'))))?>,backgroundColor:'#EF4444'}]}});</script>
<?php elseif($tab=='orders'): ?><table class="w-full text-sm bg-slate-800 rounded-2xl overflow-hidden"><tr class="text-left text-slate-400"><th class="p-3">#</th><th>Khách</th><th>SĐT</th><th>Địa chỉ</th><th>Tổng</th><th>Trạng thái</th></tr>
 <?php foreach($orders as $o): ?><tr class="border-t border-slate-700"><td class="p-3"><?=$o['id']?></td><td><?=e($o['customer_name'])?></td><td><?=e($o['phone'])?></td><td><?=e($o['address'])?></td><td class="text-red-400"><?=money($o['total'])?></td>
 <td><form method="post"><input type="hidden" name="oid" value="<?=$o['id']?>"><select name="status" onchange="this.form.submit()"><?php foreach($stl as $k=>$v) echo "<option value=$k ".($o['status']==$k?'selected':'').">$v</option>"; ?></select></form></td></tr><?php endforeach; ?></table>
<?php else: ?><form method="post" enctype="multipart/form-data" class="bg-slate-800 rounded-2xl p-5 grid md:grid-cols-4 gap-3 mb-4"><input type="hidden" name="add" value="1">
 <input name="name" required placeholder="Tên SP" class="md:col-span-2"><input name="sku" placeholder="SKU"><input name="brand" placeholder="Thương hiệu">
 <select name="category_id"><?php foreach($cats as $c) echo "<option value={$c['id']}>".e($c['name'])."</option>"; ?></select>
 <input name="price" type="number" required placeholder="Giá"><input name="sale_price" type="number" placeholder="Giá giảm"><input name="stock" type="number" value="10">
 <input name="short_desc" placeholder="Mô tả ngắn" class="md:col-span-2"><input type="file" name="image"><button class="bg-red-500 text-slate-900 font-bold rounded-xl">+ Thêm</button></form>
 <table class="w-full text-sm bg-slate-800 rounded-2xl overflow-hidden"><tr class="text-left text-slate-400"><th class="p-3">ID</th><th>Tên</th><th>Danh mục</th><th>Giá</th><th>Kho</th><th></th></tr>
 <?php foreach($prods as $p): ?><tr class="border-t border-slate-700"><td class="p-3"><?=$p['id']?></td><td><?=e($p['name'])?></td><td><?=e($p['cn'])?></td><td><?=money($p['sale_price']?:$p['price'])?></td><td><?=$p['stock']?></td>
 <td><a href="?del=<?=$p['id']?>" onclick="return confirm('Xóa sản phẩm?')" class="text-red-400"><i class="fa-solid fa-trash"></i></a></td></tr><?php endforeach; ?></table><?php endif; ?>
</main></body></html>
