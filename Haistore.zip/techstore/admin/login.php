<?php require '../includes/helpers.php'; $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){ $s=$pdo->prepare("SELECT * FROM users WHERE email=? AND role='admin'"); $s->execute([$_POST['email']]); $u=$s->fetch();
 if($u && password_verify($_POST['password'],$u['password'])){ $_SESSION['admin']=$u['name']; header('Location: index.php'); exit; } $err='Sai email hoặc mật khẩu'; } ?>
<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><script src="https://cdn.tailwindcss.com"></script><script src="<?=BASE?>assets/tailwind-theme.js"></script><link rel="stylesheet" href="<?=BASE?>assets/theme.css"></head>
<body class="bg-slate-900 text-slate-50 min-h-screen grid place-items-center"><form method="post" class="bg-slate-800 p-8 rounded-2xl w-80 space-y-3 shadow-[0_0_30px_rgba(239,68,68,.3)]">
<h1 class="text-2xl font-black text-red-400 text-center">Admin Login</h1><?php if($err) echo "<p class='text-red-400 text-sm'>$err</p>"; ?>
<input name="email" value="admin@techstore.vn" class="w-full bg-slate-900 border border-slate-600 rounded-xl p-2"><input name="password" type="password" placeholder="Mật khẩu" class="w-full bg-slate-900 border border-slate-600 rounded-xl p-2">
<button class="w-full py-2 rounded-xl bg-red-500 text-slate-900 font-bold">Đăng nhập</button></form></body></html>
