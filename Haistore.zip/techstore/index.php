<?php $title='Trang chủ'; require 'includes/header.php';
$cats=$pdo->query("SELECT * FROM categories")->fetchAll();
$flash=$pdo->query("SELECT * FROM products WHERE is_flash=1 LIMIT 4")->fetchAll();
$newest=$pdo->query("SELECT * FROM products ORDER BY id DESC LIMIT 8")->fetchAll();
$reviews=$pdo->query("SELECT r.*,p.name pn FROM reviews r JOIN products p ON p.id=r.product_id LIMIT 3")->fetchAll(); ?>
<section class="max-w-7xl mx-auto px-4 mt-6"><div class="swiper hero rounded-3xl overflow-hidden"><div class="swiper-wrapper">
 <?php foreach([['PC Flagship RTX 4070 Super','Chiến mọi tựa game 2K','from-red-600/40'],['Linh kiện mới về','CPU Intel 14 · Ryzen 7000','from-rose-600/40'],['Gear eSports','Phím cơ, chuột, màn hình 165Hz','from-red-500/30']] as $s): ?>
 <div class="swiper-slide h-72 md:h-96 bg-gradient-to-br <?=$s[2]?> to-slate-900 flex items-center px-8 md:px-16">
  <div><span class="text-xs px-3 py-1 rounded-full bg-rose-500">NEW 2026</span>
   <h1 class="text-3xl md:text-5xl font-black mt-4 neon"><?=$s[0]?></h1><p class="text-slate-300 mt-2"><?=$s[1]?></p>
   <a href="category.php" class="btn inline-block mt-6 px-6 py-3 rounded-xl font-bold">Mua ngay <i class="fa-solid fa-arrow-right"></i></a></div>
  <i class="fa-solid fa-computer text-[10rem] text-red-400/20 ml-auto hidden md:block"></i></div><?php endforeach; ?>
</div><div class="swiper-pagination"></div></div></section>

<section class="max-w-7xl mx-auto px-4 mt-12"><h2 class="text-2xl font-bold mb-4">Danh mục nổi bật</h2>
 <div class="grid grid-cols-3 md:grid-cols-6 lg:grid-cols-6 gap-4"><?php foreach($cats as $c): ?>
  <a href="category.php?cat=<?=$c['slug']?>" class="glass rounded-2xl p-5 text-center transition-all duration-300 hover:-translate-y-1 hover:glow" data-aos="zoom-in">
   <i class="fa-solid <?=$c['icon']?> text-3xl text-red-400"></i><p class="mt-2 text-sm font-semibold"><?=e($c['name'])?></p></a><?php endforeach; ?></div></section>

<section class="max-w-7xl mx-auto px-4 mt-12"><div class="flex items-center justify-between mb-4">
 <h2 class="text-2xl font-bold"><i class="fa-solid fa-fire text-orange-500"></i> Flash Sale</h2>
 <div class="flex gap-2 font-mono" id="cd"><b class="glass px-3 py-1 rounded-lg">00</b>:<b class="glass px-3 py-1 rounded-lg">00</b>:<b class="glass px-3 py-1 rounded-lg">00</b></div></div>
 <div class="grid grid-cols-2 md:grid-cols-4 gap-4"><?php foreach($flash as $p): $tot=$p['sold']+$p['stock']; ?>
  <div><?=card($p)?><div class="mt-2 px-1"><div class="h-2 rounded-full bg-slate-700"><div class="h-2 rounded-full btn" style="width:<?=round($p['sold']/$tot*100)?>%"></div></div>
  <p class="text-xs text-slate-400 mt-1">Đã bán <?=$p['sold']?>/<?=$tot?></p></div></div><?php endforeach; ?></div></section>

<section class="max-w-7xl mx-auto px-4 mt-12"><h2 class="text-2xl font-bold mb-4">Sản phẩm mới</h2>
 <div class="grid grid-cols-2 md:grid-cols-4 gap-4"><?php foreach($newest as $p) echo card($p); ?></div></section>

<section class="max-w-7xl mx-auto px-4 mt-12"><div class="rounded-3xl p-10 btn text-center" data-aos="zoom-in">
 <h2 class="text-3xl font-black">Tự Build PC theo cách của bạn</h2><p class="mt-2">Chọn từng linh kiện, kiểm tra tương thích, xem tổng tiền ngay.</p>
 <a href="#" class="inline-block mt-5 bg-slate-900 px-6 py-3 rounded-xl font-bold">Bắt đầu build</a></div></section>

<section id="dich-vu" class="max-w-7xl mx-auto px-4 mt-12"><h2 class="text-2xl font-bold mb-4"><i class="fa-solid fa-concierge-bell text-red-400"></i> Dịch vụ</h2>
 <div class="grid md:grid-cols-3 gap-4"><?php foreach([['fa-screwdriver-wrench','Lắp đặt tại nhà',300000],['fa-truck-fast','Ship tận nhà',900000],['fa-gift','Mua hộ người thân',500000]] as $sv): ?>
  <div class="glass rounded-2xl p-6 text-center transition-all duration-300 hover:-translate-y-1 hover:glow" data-aos="fade-up">
   <i class="fa-solid <?=$sv[0]?> text-4xl text-red-400"></i><h3 class="mt-3 font-bold text-lg"><?=$sv[1]?></h3>
   <p class="mt-2 text-2xl font-black text-red-400"><?=money($sv[2])?></p></div><?php endforeach; ?></div></section>

<section class="max-w-7xl mx-auto px-4 mt-12"><h2 class="text-2xl font-bold mb-4">Khách hàng nói gì</h2>
 <div class="grid md:grid-cols-3 gap-4"><?php foreach($reviews as $r): ?><div class="glass rounded-2xl p-5" data-aos="fade-up">
  <div class="text-yellow-400"><?=str_repeat('★',$r['rating'])?></div><p class="mt-2 text-slate-300">"<?=e($r['comment'])?>"</p>
  <p class="mt-3 text-sm text-red-400"><?=e($r['author'])?> · <span class="text-slate-500"><?=e($r['pn'])?></span></p></div><?php endforeach; ?></div></section>
<script>
new Swiper('.hero',{loop:true,autoplay:{delay:4000},pagination:{el:'.swiper-pagination',clickable:true}});
let end=Date.now()+8*3600*1000; setInterval(()=>{let s=Math.max(0,(end-Date.now())/1000|0),t=[s/3600|0,s/60%60|0,s%60];
 document.querySelectorAll('#cd b').forEach((b,i)=>b.textContent=String(t[i]).padStart(2,'0'));},1000);
</script>
<?php require 'includes/footer.php'; ?>
