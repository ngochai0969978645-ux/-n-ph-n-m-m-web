<?php
// Cấu hình dùng chung. Sửa tại đây nếu MySQL có mật khẩu hoặc đổi tên thư mục.
const DB_HOST='localhost', DB_NAME='techstore', DB_USER='root', DB_PASS='';
const BASE='/techstore/';   // đổi nếu bạn đặt tên thư mục khác trong htdocs
