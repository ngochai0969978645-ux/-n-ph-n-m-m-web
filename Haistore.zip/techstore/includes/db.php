<?php
require_once __DIR__.'/config.php';
function db_help($msg){
  http_response_code(500);
  die('<!DOCTYPE html><meta charset="utf-8"><body style="font-family:sans-serif;background:#1A0909;color:#F8FAFC;padding:40px;line-height:1.6">'
     .'<h2 style="color:#EF4444">Chưa có cơ sở dữ liệu</h2><p>'.$msg.'</p>'
     .'<p><a href="'.BASE.'install.php" style="background:#EF4444;color:#1A0909;padding:10px 20px;border-radius:10px;text-decoration:none;font-weight:bold">Cài đặt cơ sở dữ liệu tự động</a></p></body>');
}
try {
  $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]);
} catch (PDOException $e) { db_help('Không kết nối được cơ sở dữ liệu <b>'.DB_NAME.'</b>. Hãy bật MySQL trong XAMPP rồi bấm nút bên dưới để tạo.'); }
// Tự tạo tài khoản admin lần đầu: admin@techstore.vn / admin123
try {
  if (!$pdo->query("SELECT 1 FROM users WHERE role='admin' LIMIT 1")->fetch()) {
    $pdo->prepare("INSERT INTO users(name,email,password,role) VALUES('Admin','admin@techstore.vn',?,'admin')")
        ->execute([password_hash('admin123', PASSWORD_DEFAULT)]);
  }
} catch (PDOException $e) {
  if ($e->getCode()==='42S02') db_help('Cơ sở dữ liệu <b>'.DB_NAME.'</b> đã có nhưng chưa có bảng nào (chưa import <code>schema.sql</code>).');
  throw $e;
}
