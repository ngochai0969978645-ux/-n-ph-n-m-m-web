<?php
if (session_status()===PHP_SESSION_NONE) session_start();
require_once __DIR__.'/db.php';
function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function money($n){ return number_format((float)$n,0,',','.').'₫'; }
function cart_count(){ return array_sum($_SESSION['cart'] ?? []); }
function cart_items(){
  global $pdo; $c=$_SESSION['cart'] ?? []; if(!$c) return [];
  $in=implode(',',array_fill(0,count($c),'?'));
  $st=$pdo->prepare("SELECT * FROM products WHERE id IN ($in)"); $st->execute(array_keys($c)); $r=[];
  foreach($st as $p){ $p['qty']=$c[$p['id']]; $p['now']=$p['sale_price'] ?: $p['price']; $r[]=$p; }
  return $r;
}
function cart_total(){ return array_sum(array_map(fn($p)=>$p['now']*$p['qty'], cart_items())); }
function cat_icon($id){ static $m=[1=>'fa-computer',2=>'fa-microchip',3=>'fa-display',4=>'fa-memory',5=>'fa-keyboard',6=>'fa-tv',7=>'fa-server',8=>'fa-hard-drive',9=>'fa-plug',10=>'fa-box',11=>'fa-fan']; return $m[$id] ?? 'fa-microchip'; }
function thumb($p,$cls='text-6xl'){
  if(!empty($p['image'])) return '<img src="'.BASE.'uploads/'.e($p['image']).'" class="w-full h-full object-cover" alt="">';
  return '<i class="fa-solid '.cat_icon($p['category_id']).' '.$cls.' text-red-400/70"></i>';
}
function card($p){
  $now=$p['sale_price'] ?: $p['price']; $off=$p['sale_price']?round(100-$p['sale_price']/$p['price']*100):0;
  ob_start(); ?>
  <div class="group glass rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:glow" data-aos="fade-up">
    <a href="<?=BASE?>detail.php?id=<?=$p['id']?>" class="relative block h-44 bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center">
      <?=thumb($p)?>
      <?php if($off): ?><span class="absolute top-3 left-3 text-xs font-bold px-2 py-1 rounded-full bg-rose-500">-<?=$off?>%</span><?php endif; ?>
    </a>
    <div class="p-4">
      <p class="text-xs text-slate-400 mb-1"><?=e($p['brand'])?></p>
      <a href="<?=BASE?>detail.php?id=<?=$p['id']?>" class="font-semibold line-clamp-2 h-12 hover:text-red-400"><?=e($p['name'])?></a>
      <div class="mt-2"><span class="text-red-400 font-bold text-lg"><?=money($now)?></span>
        <?php if($off): ?><span class="text-slate-500 line-through text-sm ml-2"><?=money($p['price'])?></span><?php endif; ?></div>
      <button onclick="addToCart(<?=$p['id']?>)" class="mt-3 w-full py-2 rounded-xl bg-red-500/10 text-red-400 border border-red-500/40 hover:bg-red-500 hover:text-slate-900 transition font-semibold">
        <i class="fa-solid fa-cart-plus mr-1"></i>Thêm vào giỏ</button>
    </div>
  </div><?php return ob_get_clean();
}
