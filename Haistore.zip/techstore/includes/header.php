<?php require_once __DIR__.'/helpers.php';
$cats=$pdo->query("SELECT * FROM categories")->fetchAll(); ?>
<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($title ?? 'Hai Store')?> | Hai Store</title>
<script src="https://cdn.tailwindcss.com"></script><script src="<?=BASE?>assets/tailwind-theme.js"></script><link rel="stylesheet" href="<?=BASE?>assets/theme.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
<link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
 body{background:#1A0909;color:#F8FAFC;font-family:Inter,system-ui,sans-serif}
 .glass{background:rgba(46,20,20,.65);backdrop-filter:blur(12px);border:1px solid rgba(248,113,113,.18)}
 .hover\:glow:hover{box-shadow:0 0 25px rgba(239,68,68,.35);border-color:rgba(239,68,68,.5)}
 .neon{text-shadow:0 0 12px #EF4444,0 0 28px #EF4444}
 .btn{background:linear-gradient(90deg,#EF4444,#B91C1C);box-shadow:0 0 20px rgba(239,68,68,.4)}
 .btn:hover{filter:brightness(1.15)}
 input,select,textarea{background:#1A0909!important;border:1px solid #5A2D2D;border-radius:.75rem;padding:.5rem .75rem;color:#F8FAFC}
 input:focus,select:focus,textarea:focus{outline:2px solid #EF4444}
</style></head><body>
<div class="bg-gradient-to-r from-rose-700 to-red-500 text-xs py-2 text-center">
  🔥 Miễn phí giao hàng nội thành đơn từ 5 triệu · Hotline: <b>1900.0000000</b> · Thanh Xuân, Hà Nội</div>
<header class="sticky top-0 z-40 glass">
 <div class="max-w-7xl mx-auto px-4 py-3 flex items-center gap-4">
  <a href="<?=BASE?>" class="text-2xl font-black neon text-red-400 whitespace-nowrap"><i class="fa-solid fa-bolt"></i> Hai Store</a>
  <form action="<?=BASE?>category.php" class="flex-1 relative hidden md:block">
   <input name="q" id="q" autocomplete="off" placeholder="Tìm CPU, VGA, RAM, PC gaming..." class="w-full pl-10">
   <i class="fa-solid fa-magnifying-glass absolute left-3 top-3 text-slate-400"></i>
   <div id="suggest" class="absolute w-full mt-1 glass rounded-xl overflow-hidden hidden"></div>
  </form>
  <a href="<?=BASE?>cart.php" class="relative p-2 hover:text-red-400"><i class="fa-solid fa-cart-shopping text-xl"></i>
   <span id="cartCount" class="absolute -top-1 -right-2 bg-rose-500 text-xs rounded-full px-1.5"><?=cart_count()?></span></a>
  <a href="<?=BASE?>admin/login.php" class="p-2 hover:text-red-400"><i class="fa-regular fa-user text-xl"></i></a>
  <button class="md:hidden p-2" onclick="document.getElementById('mnav').classList.toggle('hidden')"><i class="fa-solid fa-bars text-xl"></i></button>
 </div>
 <nav class="border-t border-slate-700/50"><div class="max-w-7xl mx-auto px-4 hidden md:flex flex-wrap gap-x-5 gap-y-1 text-sm py-2">
  <?php foreach($cats as $c): ?><a class="hover:text-red-400 py-1" href="<?=BASE?>category.php?cat=<?=$c['slug']?>"><i class="fa-solid <?=$c['icon']?> mr-1 text-red-400"></i><?=e($c['name'])?></a><?php endforeach; ?>
  <a class="hover:text-red-400 py-1" href="<?=BASE?>index.php#dich-vu"><i class="fa-solid fa-concierge-bell mr-1 text-red-400"></i>Dịch vụ</a>
  <a class="hover:text-rose-400 py-1 ml-auto" href="#"><i class="fa-solid fa-screwdriver-wrench mr-1"></i>Tự Build PC</a>
 </div>
 <div id="mnav" class="hidden md:hidden px-4 pb-3 grid grid-cols-2 gap-2 text-sm">
  <?php foreach($cats as $c): ?><a class="glass rounded-lg p-2" href="<?=BASE?>category.php?cat=<?=$c['slug']?>"><?=e($c['name'])?></a><?php endforeach; ?>
  <a class="glass rounded-lg p-2" href="<?=BASE?>index.php#dich-vu">Dịch vụ</a></div></nav>
</header>
<main>
