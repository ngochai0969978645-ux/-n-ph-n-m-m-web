</main>
<footer class="mt-20 glass border-t border-slate-700/50"><div class="max-w-7xl mx-auto px-4 py-10 grid md:grid-cols-4 gap-8 text-sm text-slate-400">
 <div><h4 class="text-red-400 font-black text-xl neon mb-2">Hai Store</h4><p>Máy tính, linh kiện & gear chính hãng. Bảo hành tận tâm.</p></div>
 <div><h5 class="text-white font-semibold mb-2">Chính sách</h5><p>Bảo hành 12-36 tháng<br>Đổi trả 7 ngày<br>Giao hàng toàn quốc</p></div>
 <div><h5 class="text-white font-semibold mb-2">Thanh toán</h5><p><i class="fa-brands fa-cc-visa"></i> Visa · QR · COD</p></div>
 <div><h5 class="text-white font-semibold mb-2">Kết nối</h5><p class="text-xl space-x-3"><i class="fa-brands fa-facebook"></i><i class="fa-brands fa-youtube"></i><i class="fa-brands fa-tiktok"></i></p></div>
</div><p class="text-center text-xs text-slate-500 pb-6">© 2026 Hai Store – Đồ án phần mềm web – Ngô Ngọc Hai</p></footer>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script>
AOS.init({duration:600,once:true});
const BASE='<?=BASE?>';
function addToCart(id,qty=1){
  fetch(BASE+'api/cart.php',{method:'POST',body:new URLSearchParams({action:'add',id,qty})}).then(r=>r.json()).then(d=>{
    document.getElementById('cartCount').textContent=d.count;
    Swal.fire({toast:true,position:'top-end',icon:'success',title:'Đã thêm vào giỏ hàng',showConfirmButton:false,timer:1500,background:'#2E1414',color:'#F8FAFC'});
  });
}
const q=document.getElementById('q'),sg=document.getElementById('suggest');
if(q) q.addEventListener('input',()=>{ if(q.value.length<2){sg.classList.add('hidden');return;}
  fetch(BASE+'api/search.php?q='+encodeURIComponent(q.value)).then(r=>r.json()).then(list=>{
    sg.innerHTML=list.map(p=>`<a class="block px-4 py-2 hover:bg-slate-700 text-sm" href="${BASE}detail.php?id=${p.id}">${p.name} <span class="text-red-400 float-right">${p.price}</span></a>`).join('');
    sg.classList.toggle('hidden',!list.length);});});
</script></body></html>
