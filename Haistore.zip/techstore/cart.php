<?php $title='Giỏ hàng'; require 'includes/header.php'; $items=cart_items(); ?>
<div class="max-w-5xl mx-auto px-4 mt-8"><h1 class="text-2xl font-bold mb-4"><i class="fa-solid fa-cart-shopping text-red-400"></i> Giỏ hàng</h1>
<?php if(!$items): ?><div class="glass rounded-2xl p-16 text-center text-slate-400">Giỏ hàng trống. <a class="text-red-400" href="category.php">Mua sắm ngay</a></div>
<?php else: ?><div class="glass rounded-2xl p-4 space-y-3"><?php foreach($items as $p): ?>
 <div class="flex items-center gap-4 border-b border-slate-700/50 pb-3" id="row<?=$p['id']?>">
  <div class="w-20 h-20 rounded-xl bg-slate-800 grid place-items-center overflow-hidden"><?=thumb($p,'text-3xl')?></div>
  <div class="flex-1"><a href="detail.php?id=<?=$p['id']?>" class="font-semibold"><?=e($p['name'])?></a><p class="text-red-400"><?=money($p['now'])?></p></div>
  <div class="flex items-center gap-2"><button onclick="setQty(<?=$p['id']?>,-1)" class="w-8 h-8 glass rounded-lg">−</button>
   <b id="q<?=$p['id']?>" class="w-6 text-center"><?=$p['qty']?></b><button onclick="setQty(<?=$p['id']?>,1)" class="w-8 h-8 glass rounded-lg">+</button></div>
  <b id="l<?=$p['id']?>" class="w-28 text-right"><?=money($p['now']*$p['qty'])?></b>
  <button onclick="setQty(<?=$p['id']?>,-999)" class="text-red-400"><i class="fa-solid fa-trash"></i></button></div><?php endforeach; ?>
 <div class="flex justify-between items-center pt-2"><div class="flex gap-2"><input placeholder="Mã giảm giá"><button class="glass px-4 rounded-xl">Áp dụng</button></div>
  <div class="text-right"><p class="text-slate-400 text-sm">Tổng tiền</p><p id="total" class="text-3xl font-black text-red-400"><?=money(cart_total())?></p></div></div></div>
 <a href="checkout.php" class="btn block text-center mt-4 py-3 rounded-xl font-bold">Tiến hành thanh toán</a><?php endif; ?></div>
<script>
function setQty(id,d){ let el=document.getElementById('q'+id), n=Math.max(0,(+el.textContent)+d);
 fetch(BASE+'api/cart.php',{method:'POST',body:new URLSearchParams({action:'set',id,qty:n})}).then(r=>r.json()).then(r=>{
  document.getElementById('cartCount').textContent=r.count; document.getElementById('total').textContent=r.total;
  if(n==0){document.getElementById('row'+id).remove(); if(!r.count) location.reload();} else {el.textContent=n; document.getElementById('l'+id).textContent=r.line;}});}
</script>
<?php require 'includes/footer.php'; ?>
