<?php require_once 'includes/helpers.php'; $items=cart_items(); if(!$items){ header('Location: cart.php'); exit; }
$done=false;
if($_SERVER['REQUEST_METHOD']==='POST'){
  try{ $pdo->beginTransaction();
   $pdo->prepare("INSERT INTO orders(customer_name,phone,address,note,payment,total) VALUES(?,?,?,?,?,?)")
       ->execute([trim($_POST['name']),trim($_POST['phone']),trim($_POST['address']),trim($_POST['note']),$_POST['payment']==='qr'?'qr':'cod',cart_total()]);
   $oid=$pdo->lastInsertId(); $d=$pdo->prepare("INSERT INTO order_details(order_id,product_id,qty,price) VALUES(?,?,?,?)");
   $u=$pdo->prepare("UPDATE products SET stock=GREATEST(stock-?,0), sold=sold+? WHERE id=?");
   foreach($items as $p){ $d->execute([$oid,$p['id'],$p['qty'],$p['now']]); $u->execute([$p['qty'],$p['qty'],$p['id']]); }
   $pdo->commit(); unset($_SESSION['cart']); $done=$oid;
  }catch(Exception $e){ $pdo->rollBack(); die('Lỗi đặt hàng'); } }
$title='Thanh toán'; require 'includes/header.php'; ?>
<?php if($done): ?><script>Swal.fire({icon:'success',title:'Đặt hàng thành công!',text:'Mã đơn #<?=$done?>',background:'#2E1414',color:'#F8FAFC'}).then(()=>location='index.php')</script>
<?php else: ?>
<form method="post" class="max-w-6xl mx-auto px-4 mt-8 grid md:grid-cols-2 gap-6">
 <div class="glass rounded-2xl p-6 space-y-3"><h2 class="font-bold text-xl">Thông tin nhận hàng</h2>
  <input name="name" required placeholder="Họ tên" class="w-full"><input name="phone" required pattern="[0-9]{9,11}" placeholder="Số điện thoại" class="w-full">
  <input name="address" required placeholder="Địa chỉ giao hàng" class="w-full"><textarea name="note" placeholder="Ghi chú" class="w-full"></textarea></div>
 <div class="glass rounded-2xl p-6"><h2 class="font-bold text-xl mb-3">Đơn hàng</h2>
  <?php foreach($items as $p): ?><div class="flex justify-between text-sm py-1"><span><?=e($p['name'])?> ×<?=$p['qty']?></span><b><?=money($p['now']*$p['qty'])?></b></div><?php endforeach; ?>
  <div class="flex justify-between text-xl font-black text-red-400 border-t border-slate-700 mt-3 pt-3"><span>Tổng</span><span><?=money(cart_total())?></span></div>
  <div class="mt-4 space-y-2"><label class="glass rounded-xl p-3 flex gap-2"><input type="radio" name="payment" value="cod" checked> Thanh toán khi nhận hàng (COD)</label>
   <label class="glass rounded-xl p-3 flex gap-2"><input type="radio" name="payment" value="qr"> Chuyển khoản QR</label></div>
  <button class="btn w-full mt-4 py-3 rounded-xl font-bold">Đặt hàng</button></div></form>
<?php endif; require 'includes/footer.php'; ?>
