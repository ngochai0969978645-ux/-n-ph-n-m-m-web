<?php require '../includes/helpers.php'; header('Content-Type: application/json');
$a=$_POST['action']??''; $id=(int)($_POST['id']??0); $q=(int)($_POST['qty']??1);
if($a==='add') $_SESSION['cart'][$id]=($_SESSION['cart'][$id]??0)+max(1,$q);
if($a==='set'){ if($q<=0) unset($_SESSION['cart'][$id]); else $_SESSION['cart'][$id]=$q; }
if($a==='remove') unset($_SESSION['cart'][$id]);
$line=0; foreach(cart_items() as $p) if($p['id']==$id) $line=$p['now']*$p['qty'];
echo json_encode(['count'=>cart_count(),'line'=>money($line),'total'=>money(cart_total())]);
