<?php require '../includes/helpers.php'; header('Content-Type: application/json');
$st=$pdo->prepare("SELECT id,name,COALESCE(sale_price,price) p FROM products WHERE name LIKE ? LIMIT 6"); $st->execute(['%'.($_GET['q']??'').'%']);
echo json_encode(array_map(fn($r)=>['id'=>$r['id'],'name'=>$r['name'],'price'=>money($r['p'])], $st->fetchAll()));
