<?php
require_once __DIR__.'/includes/config.php';
if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1','::1'])) die('Chỉ chạy trên máy cục bộ (localhost).');
$msg=''; $ok=false;
if ($_SERVER['REQUEST_METHOD']==='POST') {
  try {
    $pdo=new PDO("mysql:host=".DB_HOST.";charset=utf8mb4",DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
    $sql=file_get_contents(__DIR__.'/schema.sql');
    if ($sql===false) throw new Exception('Không đọc được schema.sql (phai nằm cùng thư mục với install.php).');
    $n=0;
    foreach (preg_split('/;\s*[\r\n]+/', $sql) as $st) {
      $st=trim($st); if ($st==='') continue;
      try { $pdo->exec($st); $n++; }
      catch (PDOException $e) { throw new Exception('Lỗi ở câu lệnh: <code>'.htmlspecialchars(mb_substr($st,0,120)).'...</code><br>'.htmlspecialchars($e->getMessage())); }
    }
    $pdo->exec('USE '.DB_NAME);
    $sp=$pdo->query('SELECT COUNT(*) FROM products')->fetchColumn(); $ct=$pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn();
    $ok=true; $msg="Thành công! Đã chạy $n câu lệnh: $ct danh mục, $sp sản phẩm.";
  } catch (Exception $e) { $msg=$e->getMessage(); }
}
?><!DOCTYPE html><html lang="vi"><meta charset="utf-8"><title>Cài đặt Hai Store</title><link rel="stylesheet" href="<?=BASE?>assets/theme.css">
<body style="font-family:sans-serif;background:#1A0909;color:#F8FAFC;max-width:640px;margin:60px auto;padding:0 20px;line-height:1.6">
<h1 style="color:#EF4444">Cài đặt cơ sở dữ liệu Hai Store</h1>
<?php if($msg): ?><div style="padding:14px;border-radius:10px;background:<?=$ok?'#064E3B':'#7F1D1D'?>"><?=$msg?></div><?php endif; ?>
<?php if($ok): ?><p><a style="color:#EF4444" href="<?=BASE?>">Mở website</a> · <a style="color:#EF4444" href="<?=BASE?>admin/login.php">Trang quản trị</a> (admin@techstore.vn / admin123)</p>
<?php else: ?><p>Bấm nút dưới để tạo CSDL <b><?=DB_NAME?></b> và nạp dữ liệu mẫu từ <code>schema.sql</code>. <b>Dữ liệu cũ (nếu có) sẽ bị xóa.</b></p>
<form method="post"><button style="background:linear-gradient(90deg,#EF4444,#B91C1C);color:#fff;border:0;padding:12px 26px;border-radius:12px;font-size:16px;font-weight:bold">Cài đặt ngay</button></form><?php endif; ?>
</body></html>
