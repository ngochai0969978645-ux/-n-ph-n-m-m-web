CREATE DATABASE IF NOT EXISTS techstore CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE techstore;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS reviews, order_details, orders, products, categories, users;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE users(
  id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, email VARCHAR(120) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL, role ENUM('customer','admin') DEFAULT 'customer', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE categories(
  id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, slug VARCHAR(100) UNIQUE NOT NULL, icon VARCHAR(40) DEFAULT 'fa-microchip');
CREATE TABLE products(
  id INT AUTO_INCREMENT PRIMARY KEY, category_id INT NOT NULL, name VARCHAR(200) NOT NULL, sku VARCHAR(40),
  brand VARCHAR(50), price BIGINT NOT NULL, sale_price BIGINT DEFAULT NULL, stock INT DEFAULT 0, sold INT DEFAULT 0,
  image VARCHAR(255) DEFAULT NULL, short_desc VARCHAR(255), description TEXT, specs TEXT COMMENT 'JSON key:value',
  is_flash TINYINT(1) DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(category_id) REFERENCES categories(id));
CREATE TABLE orders(
  id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NULL, customer_name VARCHAR(100), phone VARCHAR(20), address VARCHAR(255),
  note VARCHAR(255), payment ENUM('cod','qr') DEFAULT 'cod', total BIGINT NOT NULL,
  status ENUM('pending','shipping','done','cancelled') DEFAULT 'pending', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE order_details(
  id INT AUTO_INCREMENT PRIMARY KEY, order_id INT NOT NULL, product_id INT NOT NULL, qty INT NOT NULL, price BIGINT NOT NULL,
  FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE, FOREIGN KEY(product_id) REFERENCES products(id));
CREATE TABLE reviews(
  id INT AUTO_INCREMENT PRIMARY KEY, product_id INT NOT NULL, author VARCHAR(100), rating TINYINT NOT NULL, comment TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE);

INSERT INTO categories(name,slug,icon) VALUES
('PC Gaming','pc-gaming','fa-computer'),
('CPU','cpu','fa-microchip'),
('VGA','vga','fa-display'),
('RAM','ram','fa-memory'),
('Gear','gear','fa-keyboard'),
('Màn hình','man-hinh','fa-tv'),
('Mainboard','mainboard','fa-server'),
('SSD - Ổ cứng','ssd','fa-hard-drive'),
('Nguồn máy tính','nguon','fa-plug'),
('Vỏ Case','case','fa-box'),
('Tản nhiệt','tan-nhiet','fa-fan');

INSERT INTO products(category_id,name,sku,brand,price,sale_price,stock,sold,short_desc,description,specs,is_flash) VALUES
(1,'PC Gaming Hydra i7-14700F / RTX 4070 Super','PC-001','MSI',42990000,39990000,25,46,'Flagship chiến mọi game 2K','Flagship chiến mọi game 2K. Sản phẩm chính hãng, bảo hành đầy đủ.','{"CPU": "Core i7-14700F", "VGA": "RTX 4070 Super 12GB", "RAM": "32GB DDR5", "SSD": "1TB NVMe"}',1),
(1,'PC Đồ Họa Nova Ryzen 9 / RTX 4060 Ti','PC-002','ASUS',35990000,NULL,30,174,'Dựng hình, render nhanh','Dựng hình, render nhanh. Sản phẩm chính hãng, bảo hành đầy đủ.','{"CPU": "Ryzen 9 7900", "VGA": "RTX 4060 Ti 16GB", "RAM": "64GB DDR5", "SSD": "2TB NVMe"}',0),
(2,'Intel Core i7-14700F','CPU-001','Intel',9490000,8790000,8,26,'20 nhân 28 luồng','20 nhân 28 luồng. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "LGA1700", "Nhân/Luồng": "20/28", "Xung nhịp": "5.4GHz"}',1),
(2,'AMD Ryzen 7 7800X3D','CPU-002','AMD',10990000,NULL,57,145,'CPU gaming tốt nhất','CPU gaming tốt nhất. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "AM5", "Nhân/Luồng": "8/16", "Cache": "96MB"}',0),
(3,'ASUS ROG Strix RTX 4070 Super 12GB','VGA-001','ASUS',20990000,19490000,11,101,'Tản nhiệt 3 fan','Tản nhiệt 3 fan. Sản phẩm chính hãng, bảo hành đầy đủ.','{"VRAM": "12GB GDDR6X", "Bus": "192-bit", "Nguồn": "650W"}',1),
(3,'MSI RTX 4060 Ventus 2X 8GB','VGA-002','MSI',8490000,7990000,42,22,'Gaming 1080p mượt','Gaming 1080p mượt. Sản phẩm chính hãng, bảo hành đầy đủ.','{"VRAM": "8GB GDDR6", "Bus": "128-bit", "Nguồn": "550W"}',0),
(4,'Corsair Vengeance 32GB DDR5 6000','RAM-001','Corsair',3190000,2890000,37,62,'Kit 2x16GB','Kit 2x16GB. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Dung lượng": "32GB", "Bus": "6000MHz", "Loại": "DDR5"}',1),
(4,'Kingston Fury 16GB DDR4 3200','RAM-002','Kingston',950000,NULL,7,30,'Giá tốt nâng cấp','Giá tốt nâng cấp. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Dung lượng": "16GB", "Bus": "3200MHz", "Loại": "DDR4"}',0),
(5,'Bàn phím cơ Corsair K70 RGB','GEA-001','Corsair',3290000,2790000,32,115,'Switch Cherry MX','Switch Cherry MX. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Switch": "Cherry MX Red", "Kết nối": "USB-C", "LED": "RGB"}',0),
(5,'Chuột Logitech G Pro X Superlight 2','GEA-002','Logitech',3490000,NULL,9,69,'Siêu nhẹ 60g','Siêu nhẹ 60g. Sản phẩm chính hãng, bảo hành đầy đủ.','{"DPI": "32000", "Trọng lượng": "60g", "Kết nối": "Lightspeed"}',0),
(6,'Màn hình LG UltraGear 27" 2K 165Hz','MON-001','LG',7990000,6990000,10,149,'IPS 1ms','IPS 1ms. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Kích thước": "27 inch", "Độ phân giải": "2560x1440", "Tần số": "165Hz"}',1),
(6,'Màn hình ASUS TUF 24" 144Hz','MON-002','ASUS',3990000,NULL,32,23,'Full HD 144Hz','Full HD 144Hz. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Kích thước": "24 inch", "Độ phân giải": "1920x1080", "Tần số": "144Hz"}',0),
(1,'PC Gaming Vulcan Ryzen 5 7600 / RTX 4060','PC-003','Hai Store',22990000,21490000,57,152,'Chiến game Full HD cao cấp','Chiến game Full HD cao cấp. Sản phẩm chính hãng, bảo hành đầy đủ.','{"CPU": "Ryzen 5 7600", "VGA": "RTX 4060 8GB", "RAM": "16GB DDR5", "SSD": "500GB NVMe"}',0),
(1,'PC Gaming Phoenix i5-14400F / RTX 4060 Ti','PC-004','Hai Store',25990000,NULL,12,65,'Cân bằng giá và hiệu năng','Cân bằng giá và hiệu năng. Sản phẩm chính hãng, bảo hành đầy đủ.','{"CPU": "Core i5-14400F", "VGA": "RTX 4060 Ti 8GB", "RAM": "16GB DDR5", "SSD": "1TB NVMe"}',0),
(1,'PC Gaming Titan Ryzen 7 7800X3D / RTX 4080 Super','PC-005','Hai Store',59990000,56990000,45,168,'Cấu hình đỉnh cao 4K','Cấu hình đỉnh cao 4K. Sản phẩm chính hãng, bảo hành đầy đủ.','{"CPU": "Ryzen 7 7800X3D", "VGA": "RTX 4080 Super 16GB", "RAM": "32GB DDR5", "SSD": "2TB NVMe"}',1),
(1,'PC Gaming Eco i3-12100F / GTX 1650','PC-006','Hai Store',10990000,NULL,42,23,'Máy nhập môn giá rẻ','Máy nhập môn giá rẻ. Sản phẩm chính hãng, bảo hành đầy đủ.','{"CPU": "Core i3-12100F", "VGA": "GTX 1650 4GB", "RAM": "16GB DDR4", "SSD": "256GB NVMe"}',0),
(1,'PC Streaming Orion i7-14700K / RTX 4070 Ti Super','PC-007','Hai Store',52990000,NULL,41,157,'Stream và chơi game cùng lúc','Stream và chơi game cùng lúc. Sản phẩm chính hãng, bảo hành đầy đủ.','{"CPU": "Core i7-14700K", "VGA": "RTX 4070 Ti Super 16GB", "RAM": "32GB DDR5", "SSD": "1TB NVMe"}',0),
(1,'PC Văn Phòng Slim i5-12400 / 16GB / SSD 512GB','PC-008','Hai Store',12490000,11490000,30,20,'Làm việc, học tập mượt mà','Làm việc, học tập mượt mà. Sản phẩm chính hãng, bảo hành đầy đủ.','{"CPU": "Core i5-12400", "VGA": "Intel UHD 730", "RAM": "16GB DDR4", "SSD": "512GB NVMe"}',0),
(2,'Intel Core i5-14400F','CPU-003','Intel',4990000,NULL,19,19,'10 nhân giá tốt','10 nhân giá tốt. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "LGA1700", "Nhân/Luồng": "10/16", "Xung nhịp": "4.7GHz"}',0),
(2,'Intel Core i5-14600K','CPU-004','Intel',7690000,7290000,40,42,'14 nhân mở khóa xung','14 nhân mở khóa xung. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "LGA1700", "Nhân/Luồng": "14/20", "Xung nhịp": "5.3GHz"}',0),
(2,'Intel Core i9-14900K','CPU-005','Intel',14990000,13990000,23,115,'24 nhân đỉnh cao','24 nhân đỉnh cao. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "LGA1700", "Nhân/Luồng": "24/32", "Xung nhịp": "6.0GHz"}',0),
(2,'Intel Core i3-12100F','CPU-006','Intel',2390000,NULL,14,146,'4 nhân nhập môn','4 nhân nhập môn. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "LGA1700", "Nhân/Luồng": "4/8", "Xung nhịp": "4.3GHz"}',0),
(2,'AMD Ryzen 5 7600','CPU-007','AMD',5290000,NULL,12,154,'6 nhân nền tảng AM5','6 nhân nền tảng AM5. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "AM5", "Nhân/Luồng": "6/12", "Xung nhịp": "5.1GHz"}',0),
(2,'AMD Ryzen 5 5600','CPU-008','AMD',2790000,2590000,24,151,'Tiết kiệm nền tảng AM4','Tiết kiệm nền tảng AM4. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "AM4", "Nhân/Luồng": "6/12", "Xung nhịp": "4.4GHz"}',0),
(2,'AMD Ryzen 7 7700X','CPU-009','AMD',8490000,NULL,57,54,'8 nhân mạnh mẽ','8 nhân mạnh mẽ. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "AM5", "Nhân/Luồng": "8/16", "Xung nhịp": "5.4GHz"}',0),
(2,'AMD Ryzen 9 7950X','CPU-010','AMD',15990000,14990000,11,156,'16 nhân cho sáng tạo nội dung','16 nhân cho sáng tạo nội dung. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "AM5", "Nhân/Luồng": "16/32", "Xung nhịp": "5.7GHz"}',0),
(2,'Intel Core Ultra 7 265K','CPU-011','Intel',11490000,NULL,41,171,'Kiến trúc Arrow Lake','Kiến trúc Arrow Lake. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "LGA1851", "Nhân/Luồng": "20/20", "Xung nhịp": "5.5GHz"}',0),
(3,'Gigabyte RTX 4060 Ti Eagle OC 8GB','VGA-003','Gigabyte',11490000,NULL,17,103,'Mát và êm','Mát và êm. Sản phẩm chính hãng, bảo hành đầy đủ.','{"VRAM": "8GB GDDR6", "Bus": "128-bit", "Nguồn": "550W"}',0),
(3,'Gigabyte RTX 4070 Ti Super Gaming OC 16GB','VGA-004','Gigabyte',24990000,23990000,11,148,'Chiến game 4K','Chiến game 4K. Sản phẩm chính hãng, bảo hành đầy đủ.','{"VRAM": "16GB GDDR6X", "Bus": "256-bit", "Nguồn": "700W"}',0),
(3,'MSI RTX 4080 Super Gaming X Trio 16GB','VGA-005','MSI',31990000,30490000,50,24,'Hiệu năng cực cao','Hiệu năng cực cao. Sản phẩm chính hãng, bảo hành đầy đủ.','{"VRAM": "16GB GDDR6X", "Bus": "256-bit", "Nguồn": "750W"}',0),
(3,'ASUS TUF RTX 4090 OC 24GB','VGA-006','ASUS',52990000,NULL,41,23,'Quái vật đồ họa','Quái vật đồ họa. Sản phẩm chính hãng, bảo hành đầy đủ.','{"VRAM": "24GB GDDR6X", "Bus": "384-bit", "Nguồn": "850W"}',0),
(3,'Sapphire Pulse RX 7600 XT 16GB','VGA-007','Sapphire',9290000,8790000,44,60,'16GB VRAM giá tốt','16GB VRAM giá tốt. Sản phẩm chính hãng, bảo hành đầy đủ.','{"VRAM": "16GB GDDR6", "Bus": "128-bit", "Nguồn": "550W"}',0),
(3,'Sapphire Nitro+ RX 7800 XT 16GB','VGA-008','Sapphire',14990000,NULL,36,144,'Mạnh cho 2K','Mạnh cho 2K. Sản phẩm chính hãng, bảo hành đầy đủ.','{"VRAM": "16GB GDDR6", "Bus": "256-bit", "Nguồn": "700W"}',0),
(3,'ASUS Dual RTX 3050 6GB','VGA-009','ASUS',4490000,NULL,32,88,'Card nhập môn','Card nhập môn. Sản phẩm chính hãng, bảo hành đầy đủ.','{"VRAM": "6GB GDDR6", "Bus": "96-bit", "Nguồn": "450W"}',0),
(3,'XFX Speedster RX 7900 XTX 24GB','VGA-010','XFX',23990000,22490000,34,157,'24GB VRAM','24GB VRAM. Sản phẩm chính hãng, bảo hành đầy đủ.','{"VRAM": "24GB GDDR6", "Bus": "384-bit", "Nguồn": "800W"}',0),
(4,'G.Skill Trident Z5 RGB 32GB DDR5 6400','RAM-003','G.Skill',3990000,NULL,34,100,'RGB, xung cao','RGB, xung cao. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Dung lượng": "32GB", "Bus": "6400MHz", "Loại": "DDR5"}',0),
(4,'Kingston Fury Beast 16GB DDR5 5600','RAM-004','Kingston',1690000,NULL,24,71,'DDR5 giá mềm','DDR5 giá mềm. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Dung lượng": "16GB", "Bus": "5600MHz", "Loại": "DDR5"}',0),
(4,'Corsair Vengeance 64GB DDR5 6000','RAM-005','Corsair',6490000,5990000,55,54,'Kit 2x32GB','Kit 2x32GB. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Dung lượng": "64GB", "Bus": "6000MHz", "Loại": "DDR5"}',0),
(4,'TeamGroup T-Force Delta RGB 16GB DDR4 3600','RAM-006','TeamGroup',1190000,NULL,49,70,'LED RGB','LED RGB. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Dung lượng": "16GB", "Bus": "3600MHz", "Loại": "DDR4"}',0),
(4,'ADATA XPG Lancer 32GB DDR5 6000','RAM-007','ADATA',2990000,2790000,10,155,'Kit 2x16GB','Kit 2x16GB. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Dung lượng": "32GB", "Bus": "6000MHz", "Loại": "DDR5"}',0),
(5,'Bàn phím cơ Razer BlackWidow V4','GEA-003','Razer',3990000,NULL,24,142,'Switch Razer Green','Switch Razer Green. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Switch": "Razer Green", "Kết nối": "USB", "LED": "RGB Chroma"}',0),
(5,'Bàn phím Logitech G Pro X TKL Lightspeed','GEA-004','Logitech',4490000,3990000,36,95,'Không dây, gọn nhẹ','Không dây, gọn nhẹ. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Switch": "GX Tactile", "Kết nối": "Lightspeed", "LED": "RGB"}',0),
(5,'Bàn phím cơ Akko 3068B Plus','GEA-005','Akko',1790000,NULL,51,122,'Layout 65%, 3 chế độ','Layout 65%, 3 chế độ. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Switch": "Akko CS", "Kết nối": "BT/2.4G/USB-C", "LED": "RGB"}',0),
(5,'Chuột Razer DeathAdder V3 Pro','GEA-006','Razer',3690000,NULL,23,163,'Không dây 63g','Không dây 63g. Sản phẩm chính hãng, bảo hành đầy đủ.','{"DPI": "30000", "Trọng lượng": "63g", "Kết nối": "HyperSpeed"}',0),
(5,'Chuột Logitech G502 X','GEA-007','Logitech',1590000,1390000,9,38,'Nhiều nút lập trình','Nhiều nút lập trình. Sản phẩm chính hãng, bảo hành đầy đủ.','{"DPI": "25600", "Trọng lượng": "89g", "Kết nối": "USB"}',0),
(5,'Tai nghe Corsair HS80 RGB Wireless','GEA-008','Corsair',3290000,NULL,37,115,'Âm thanh vòm 7.1','Âm thanh vòm 7.1. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Loại": "Over-ear", "Kết nối": "Slipstream", "Mic": "Có"}',0),
(5,'Tai nghe HyperX Cloud II','GEA-009','HyperX',2290000,1890000,15,95,'Đệm tai êm','Đệm tai êm. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Loại": "Over-ear", "Kết nối": "USB", "Mic": "Có"}',0),
(5,'Tai nghe SteelSeries Arctis Nova 7','GEA-010','SteelSeries',4290000,NULL,14,133,'Không dây, pin 38 giờ','Không dây, pin 38 giờ. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Loại": "Over-ear", "Kết nối": "2.4GHz/BT", "Mic": "Có"}',0),
(5,'Lót chuột Razer Gigantus V2 XXL','GEA-011','Razer',590000,NULL,31,18,'Cỡ lớn 940x410mm','Cỡ lớn 940x410mm. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Kích thước": "940x410mm", "Bề mặt": "Vải", "Đế": "Cao su"}',0),
(5,'Webcam Logitech C920 HD Pro','GEA-012','Logitech',1690000,NULL,47,27,'Full HD 1080p','Full HD 1080p. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Độ phân giải": "1080p", "Khung hình": "30fps", "Kết nối": "USB"}',0),
(6,'Màn hình Samsung Odyssey G5 27" 2K 165Hz','MON-003','Samsung',6490000,NULL,53,150,'Cong 1000R','Cong 1000R. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Kích thước": "27 inch", "Độ phân giải": "2560x1440", "Tần số": "165Hz"}',0),
(6,'Màn hình MSI MAG 274QRF QD 27" 2K 165Hz','MON-004','MSI',7290000,6790000,41,88,'Quantum Dot','Quantum Dot. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Kích thước": "27 inch", "Độ phân giải": "2560x1440", "Tần số": "165Hz"}',0),
(6,'Màn hình ASUS ROG Swift OLED 27" 240Hz','MON-005','ASUS',26990000,NULL,26,97,'OLED phản hồi 0.03ms','OLED phản hồi 0.03ms. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Kích thước": "27 inch", "Độ phân giải": "2560x1440", "Tần số": "240Hz"}',0),
(6,'Màn hình Gigabyte M27Q 27" 2K 170Hz','MON-006','Gigabyte',6990000,NULL,43,135,'IPS KVM','IPS KVM. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Kích thước": "27 inch", "Độ phân giải": "2560x1440", "Tần số": "170Hz"}',0),
(6,'Màn hình ViewSonic VX2528 25" 240Hz','MON-007','ViewSonic',4990000,4590000,42,124,'Full HD 240Hz','Full HD 240Hz. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Kích thước": "25 inch", "Độ phân giải": "1920x1080", "Tần số": "240Hz"}',0),
(6,'Màn hình LG UltraGear 34" Ultrawide 144Hz','MON-008','LG',11990000,NULL,9,31,'21:9 WQHD','21:9 WQHD. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Kích thước": "34 inch", "Độ phân giải": "3440x1440", "Tần số": "144Hz"}',0),
(6,'Màn hình AOC 24G2 24" 144Hz','MON-009','AOC',3590000,NULL,22,129,'IPS viền mỏng','IPS viền mỏng. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Kích thước": "24 inch", "Độ phân giải": "1920x1080", "Tần số": "144Hz"}',0),
(7,'Mainboard ASUS TUF Gaming B760M-Plus WiFi D4','MB-001','ASUS',4290000,NULL,49,178,'Micro-ATX, DDR4','Micro-ATX, DDR4. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "LGA1700", "Chipset": "B760", "RAM": "DDR4", "Kích thước": "mATX"}',0),
(7,'Mainboard MSI MAG B650 Tomahawk WiFi','MB-002','MSI',6690000,6290000,9,23,'Nền tảng AM5 bền bỉ','Nền tảng AM5 bền bỉ. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "AM5", "Chipset": "B650", "RAM": "DDR5", "Kích thước": "ATX"}',0),
(7,'Mainboard Gigabyte B650M Aorus Elite AX','MB-003','Gigabyte',4990000,NULL,51,87,'WiFi 6E, mATX','WiFi 6E, mATX. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "AM5", "Chipset": "B650", "RAM": "DDR5", "Kích thước": "mATX"}',0),
(7,'Mainboard ASUS ROG Strix Z790-E Gaming WiFi','MB-004','ASUS',11990000,11290000,46,155,'Cao cấp cho i7, i9','Cao cấp cho i7, i9. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "LGA1700", "Chipset": "Z790", "RAM": "DDR5", "Kích thước": "ATX"}',0),
(7,'Mainboard MSI PRO H610M-E DDR4','MB-005','MSI',1790000,NULL,48,122,'Giá rẻ văn phòng','Giá rẻ văn phòng. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "LGA1700", "Chipset": "H610", "RAM": "DDR4", "Kích thước": "mATX"}',0),
(7,'Mainboard ASRock B550M Pro4','MB-006','ASRock',2690000,NULL,23,106,'Nền tảng AM4','Nền tảng AM4. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "AM4", "Chipset": "B550", "RAM": "DDR4", "Kích thước": "mATX"}',0),
(7,'Mainboard ASUS Prime A620M-K','MB-007','ASUS',2490000,NULL,47,96,'AM5 giá tốt','AM5 giá tốt. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Socket": "AM5", "Chipset": "A620", "RAM": "DDR5", "Kích thước": "mATX"}',0),
(8,'SSD Samsung 980 Pro 1TB NVMe','SSD-001','Samsung',3290000,NULL,6,126,'PCIe 4.0 tốc độ cao','PCIe 4.0 tốc độ cao. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Dung lượng": "1TB", "Chuẩn": "NVMe PCIe 4.0", "Đọc": "7000MB/s"}',0),
(8,'SSD Samsung 990 Pro 2TB NVMe','SSD-002','Samsung',5990000,5490000,27,51,'Hiệu năng hàng đầu','Hiệu năng hàng đầu. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Dung lượng": "2TB", "Chuẩn": "NVMe PCIe 4.0", "Đọc": "7450MB/s"}',0),
(8,'SSD WD Black SN850X 1TB NVMe','SSD-003','WD',3190000,NULL,44,37,'Tối ưu cho game','Tối ưu cho game. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Dung lượng": "1TB", "Chuẩn": "NVMe PCIe 4.0", "Đọc": "7300MB/s"}',0),
(8,'SSD Kingston NV2 500GB NVMe','SSD-004','Kingston',990000,NULL,36,23,'Giá rẻ nâng cấp','Giá rẻ nâng cấp. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Dung lượng": "500GB", "Chuẩn": "NVMe PCIe 4.0", "Đọc": "3500MB/s"}',0),
(8,'SSD Crucial P3 Plus 1TB NVMe','SSD-005','Crucial',2190000,1990000,18,81,'PCIe 4.0 phổ thông','PCIe 4.0 phổ thông. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Dung lượng": "1TB", "Chuẩn": "NVMe PCIe 4.0", "Đọc": "5000MB/s"}',0),
(8,'SSD Lexar NM790 2TB NVMe','SSD-006','Lexar',3690000,NULL,13,71,'2TB giá tốt','2TB giá tốt. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Dung lượng": "2TB", "Chuẩn": "NVMe PCIe 4.0", "Đọc": "7400MB/s"}',0),
(8,'Ổ cứng HDD Seagate Barracuda 2TB','HDD-001','Seagate',1690000,NULL,30,108,'Lưu trữ dung lượng lớn','Lưu trữ dung lượng lớn. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Dung lượng": "2TB", "Chuẩn": "SATA III", "Tốc độ": "7200rpm"}',0),
(9,'Nguồn Corsair RM850e 850W 80+ Gold','PSU-001','Corsair',3290000,NULL,60,135,'Full modular','Full modular. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Công suất": "850W", "Chuẩn": "80+ Gold", "Modular": "Full"}',0),
(9,'Nguồn MSI MAG A750GL 750W 80+ Gold','PSU-002','MSI',2490000,2290000,10,50,'Hỗ trợ ATX 3.0','Hỗ trợ ATX 3.0. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Công suất": "750W", "Chuẩn": "80+ Gold", "Modular": "Full"}',0),
(9,'Nguồn Cooler Master MWE 650W Bronze','PSU-003','Cooler Master',1390000,NULL,33,110,'Phổ thông','Phổ thông. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Công suất": "650W", "Chuẩn": "80+ Bronze", "Modular": "Không"}',0),
(9,'Nguồn Seasonic Focus GX-1000 1000W','PSU-004','Seasonic',4590000,NULL,40,79,'Cho cấu hình RTX 4090','Cho cấu hình RTX 4090. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Công suất": "1000W", "Chuẩn": "80+ Gold", "Modular": "Full"}',0),
(9,'Nguồn Gigabyte P550B 550W Bronze','PSU-005','Gigabyte',1090000,NULL,13,118,'Giá rẻ','Giá rẻ. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Công suất": "550W", "Chuẩn": "80+ Bronze", "Modular": "Không"}',0),
(10,'Case Lian Li Lancool 216','CAS-001','Lian Li',2890000,NULL,60,148,'Luồng khí xuất sắc','Luồng khí xuất sắc. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Kích thước": "Mid Tower", "Hỗ trợ": "ATX", "Quạt": "2 fan 160mm"}',0),
(10,'Case NZXT H7 Flow','CAS-002','NZXT',3490000,3190000,22,114,'Thiết kế tối giản','Thiết kế tối giản. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Kích thước": "Mid Tower", "Hỗ trợ": "ATX", "Quạt": "2 fan 120mm"}',0),
(10,'Case Corsair 4000D Airflow','CAS-003','Corsair',2290000,1990000,27,105,'Dễ lắp ráp','Dễ lắp ráp. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Kích thước": "Mid Tower", "Hỗ trợ": "ATX", "Quạt": "2 fan 120mm"}',0),
(10,'Case Cooler Master NR200P Mini-ITX','CAS-004','Cooler Master',2790000,NULL,19,46,'Nhỏ gọn','Nhỏ gọn. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Kích thước": "Mini-ITX", "Hỗ trợ": "ITX", "Quạt": "2 fan 120mm"}',0),
(10,'Case Xigmatek Gaming X 3 Fan RGB','CAS-005','Xigmatek',890000,NULL,10,53,'Giá rẻ, kính cường lực','Giá rẻ, kính cường lực. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Kích thước": "Mid Tower", "Hỗ trợ": "ATX", "Quạt": "3 fan RGB"}',0),
(11,'Tản nhiệt khí Deepcool AK620','COO-001','Deepcool',1590000,NULL,14,67,'Tản kép hiệu quả cao','Tản kép hiệu quả cao. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Loại": "Tản khí", "Socket": "LGA1700/AM5", "TDP": "260W"}',0),
(11,'Tản nhiệt Thermalright Peerless Assassin 120 SE','COO-002','Thermalright',890000,NULL,47,67,'Giá tốt nhất phân khúc','Giá tốt nhất phân khúc. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Loại": "Tản khí", "Socket": "LGA1700/AM5", "TDP": "250W"}',0),
(11,'Tản nhiệt nước Corsair iCUE H150i Elite 360','COO-003','Corsair',4590000,4290000,5,132,'AIO 360mm LED','AIO 360mm LED. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Loại": "AIO 360mm", "Socket": "LGA1700/AM5", "TDP": "300W"}',0),
(11,'Tản nhiệt nước NZXT Kraken 240','COO-004','NZXT',3990000,3490000,58,158,'AIO 240mm có màn hình','AIO 240mm có màn hình. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Loại": "AIO 240mm", "Socket": "LGA1700/AM5", "TDP": "280W"}',0),
(11,'Tản nhiệt khí Noctua NH-U12S','COO-005','Noctua',2290000,NULL,16,75,'Êm ái, bền bỉ','Êm ái, bền bỉ. Sản phẩm chính hãng, bảo hành đầy đủ.','{"Loại": "Tản khí", "Socket": "LGA1700/AM5", "TDP": "200W"}',0);

INSERT INTO reviews(product_id,author,rating,comment) VALUES
(1,'Minh Quân',5,'Máy chạy rất mượt, build đẹp!'),(1,'Hai Nam',4,'Giao nhanh, đóng gói kỹ.'),(5,'Tuấn Anh',5,'Card mát, êm.'),
(3,'Đức Huy',5,'CPU mạnh, render nhanh hơn hẳn.'),(7,'Thu Hà',4,'RAM chạy ổn định, giá hợp lý.'),(9,'Bảo Long',5,'Gõ phím rất sướng, led đẹp.'),
(11,'Quang Vinh',5,'Màu sắc đẹp, 165Hz chơi mượt.'),(13,'Khánh Linh',4,'Máy chạy game tốt trong tầm giá.'),(41,'Hoàng Phúc',5,'Phím cơ gõ êm, kết nối ổn.');
