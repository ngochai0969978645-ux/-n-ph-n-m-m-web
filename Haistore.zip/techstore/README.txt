HAI STORE – Website bán hàng công nghệ (tác giả: Ngô Ngọc Hai)

CÀI ĐẶT TRÊN XAMPP
1. Giải nén thư mục "techstore" vào C:\xampp\htdocs\
2. Bật Apache + MySQL trong XAMPP Control Panel
3. Cách 1 (dễ nhất): mở http://localhost/techstore/install.php rồi bấm "Cài đặt ngay".
   Cách 2: mở http://localhost/phpmyadmin -> tab Import -> chọn schema.sql -> Go
4. Truy cập http://localhost/techstore/
5. Admin: http://localhost/techstore/admin/login.php  (admin@techstore.vn / admin123)
Nếu đổi tên thư mục, sửa hằng BASE trong includes/db.php. Nếu MySQL có mật khẩu root, sửa DB_PASS.
